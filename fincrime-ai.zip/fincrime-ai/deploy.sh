#!/usr/bin/env bash
# One-shot deploy: Firestore + Cloud Run + Firebase Hosting.
# Prereqs: gcloud and firebase CLIs logged in, billing enabled on the project.
# Usage: PROJECT_ID=my-project ./deploy.sh
set -euo pipefail
: "${PROJECT_ID:?set PROJECT_ID}"
REGION="${REGION:-asia-south1}"
SA="fincrime-ai-sa"
gcloud config set project "$PROJECT_ID"
gcloud services enable run.googleapis.com firestore.googleapis.com aiplatform.googleapis.com cloudbuild.googleapis.com artifactregistry.googleapis.com firebase.googleapis.com firebasehosting.googleapis.com
gcloud firestore databases create --location="$REGION" 2>/dev/null || echo "Firestore database already exists"
gcloud iam service-accounts create "$SA" --display-name="FinCrime AI" 2>/dev/null || true
for ROLE in roles/datastore.user roles/aiplatform.user; do
  gcloud projects add-iam-policy-binding "$PROJECT_ID" --member="serviceAccount:$SA@$PROJECT_ID.iam.gserviceaccount.com" --role="$ROLE" --condition=None >/dev/null
done
gcloud run deploy fincrime-ai --source . --region "$REGION" --allow-unauthenticated \
  --service-account "$SA@$PROJECT_ID.iam.gserviceaccount.com" \
  --set-env-vars "GOOGLE_CLOUD_PROJECT=$PROJECT_ID,GEMINI_MODEL=${GEMINI_MODEL:-gemini-2.5-flash},GEMINI_LOCATION=${GEMINI_LOCATION:-us-central1}" \
  --min-instances 1 --memory 512Mi
# Firebase Hosting in front of Cloud Run (gives you https://$PROJECT_ID.web.app)
firebase use "$PROJECT_ID" 2>/dev/null || firebase use --add "$PROJECT_ID"
firebase deploy --only hosting,firestore:rules
echo "Cloud Run URL:"; gcloud run services describe fincrime-ai --region "$REGION" --format='value(status.url)'
echo "Firebase URL: https://$PROJECT_ID.web.app"
echo "Health check: curl https://$PROJECT_ID.web.app/api/health   (expect store=firestore)"
