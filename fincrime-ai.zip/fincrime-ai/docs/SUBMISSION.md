# FinCrime AI – submission pack

## Brief description (paste into the form)
FinCrime AI is an AI-assisted AML and fraud investigation platform. A transparent rules engine detects six typologies (structuring below the reporting threshold, rapid pass-through, high-risk jurisdictions, mule-like velocity, dormant-account reactivation, profile mismatch) and scores each customer 0-100 with the exact transactions as evidence. Gemini (gemini-2.5-flash, called through Vertex AI) turns each alert into an investigation brief: summary, likely typology, red flags citing transaction IDs, possible innocent explanations, a recommended action and a draft suspicious-transaction report narrative, plus a case copilot for follow-up questions. The analyst always decides (escalate, monitor, close). The backend runs on Cloud Run under a least-privilege service account; Cloud Firestore stores customers, transactions and cases (including AI analysis and an audit timeline); Firebase Hosting fronts Cloud Run over HTTPS and deploys the Firestore security rules, which deny all direct client access. New transactions can be screened in real time. All data is synthetic.

## Deploy (about 10 minutes)
1. Create a GCP project with billing; install gcloud and firebase CLIs and log in (`gcloud auth login`, `firebase login`).
2. Create a public GitHub repo `fincrime-ai`, then from the project folder:
   `git init && git add . && git commit -m "FinCrime AI" && git branch -M main && git remote add origin https://github.com/<you>/fincrime-ai.git && git push -u origin main`
3. `PROJECT_ID=<your-project> ./deploy.sh`
4. Verify: `curl https://<your-project>.web.app/api/health` must show `"store":"firestore"`. Open the app, click an alert, click "Analyze with Gemini": the badge must read **Gemini · gemini-2.5-flash**, not "Offline template". If it says offline, the error is in the `note` field of the API response; the usual cause is the Vertex AI API not enabled or `roles/aiplatform.user` missing on the service account (or set a `GEMINI_API_KEY` env var on the Cloud Run service).
5. Keep `--min-instances 1` (already in deploy.sh) so the prototype is warm during evaluation.
6. Open the repo, video and app links in a private window. Put them on slide 13 of the deck (red text) and in the form.

## 3:30 demo video script
- 0:00-0:20 Problem: analysts drown in alerts and hand-write every STR. Introduce FinCrime AI and the stack (Cloud Run, Firestore, Firebase, Gemini).
- 0:20-1:00 Dashboard: KPIs, ranked queue, open the top case, show the rules that fired and the red timeline bars.
- 1:00-2:00 Click "Analyze with Gemini": walk through summary, red flags with transaction IDs, innocent explanations, recommendation, draft STR. Ask the copilot "Why is this suspicious?".
- 2:00-2:30 Decision: Escalate with a note; show the case timeline.
- 2:30-3:10 Live screening tab: pick a customer, use the Iran preset, show score change, decision, latency, new case.
- 3:10-3:30 Show Firestore console (cases and transactions collections), Cloud Run service, and the architecture slide. Close with the human-in-the-loop point.
Record at 1080p, keep under 4:00, upload as Public/Unlisted-accessible.
