// Gemini integration via REST. Two auth modes:
//  1) GEMINI_API_KEY  -> Gemini API (Google AI Studio key)
//  2) Cloud Run service account -> Vertex AI (no key needed; grant roles/aiplatform.user)
// If neither works, we fall back to a deterministic offline template and label the output as such.
import { getToken, getProject } from './google.js';

const MODEL = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
const LOCATION = process.env.GEMINI_LOCATION || 'us-central1';

export const geminiInfo = () => ({ model: MODEL, auth: process.env.GEMINI_API_KEY ? 'api-key' : 'vertex-service-account', location: LOCATION });

async function call({ system, prompt, json }) {
  const body = {
    systemInstruction: { parts: [{ text: system }] },
    contents: [{ role: 'user', parts: [{ text: prompt }] }],
    generationConfig: { temperature: 0.2, maxOutputTokens: 2048, ...(json ? { responseMimeType: 'application/json' } : {}) }
  };
  let url, headers = { 'Content-Type': 'application/json' };
  if (process.env.GEMINI_API_KEY) {
    url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`;
    headers['x-goog-api-key'] = process.env.GEMINI_API_KEY;
  } else {
    const project = await getProject();
    if (!project) throw new Error('No GEMINI_API_KEY and no Google project for Vertex AI');
    url = `https://${LOCATION}-aiplatform.googleapis.com/v1/projects/${project}/locations/${LOCATION}/publishers/google/models/${MODEL}:generateContent`;
    headers.Authorization = 'Bearer ' + await getToken();
  }
  const r = await fetch(url, { method: 'POST', headers, body: JSON.stringify(body), signal: AbortSignal.timeout(45000) });
  if (!r.ok) throw new Error(`Gemini ${r.status}: ${(await r.text()).slice(0, 300)}`);
  const j = await r.json();
  const text = (j.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('');
  if (!text) throw new Error('Gemini returned no text');
  return text;
}

const SYSTEM = `You are an AML/fraud investigation assistant supporting a human compliance analyst at a Nepali financial institution (bank / wallet / PSP).
Rules: use ONLY the facts in the provided case evidence; never invent names, amounts, dates or transactions; cite transaction IDs when making a point;
express uncertainty plainly; you recommend, the human decides. Amounts are in NPR. Be concise and professional.`;

export function caseContext(c, customer, txns) {
  const rows = txns.filter(t => c.hits.some(h => h.txnIds.includes(t.id)))
    .slice(0, 40).map(t => `${t.id} | ${t.ts.slice(0, 16)} | ${t.type} | NPR ${t.amount} | cp=${t.counterparty} | ${t.country}`).join('\n');
  return `CASE ${c.id} | risk score ${c.score}/100 (${c.severity})
CUSTOMER: ${customer.name} (${customer.id}), ${customer.kind}, occupation ${customer.occupation}, risk rating ${customer.riskRating}, expected monthly turnover NPR ${customer.expectedMonthly}, account opened ${customer.openedAt}
RULES TRIGGERED:
${c.hits.map(h => `- [${h.id}] ${h.name}: ${h.detail}`).join('\n')}
FLAGGED TRANSACTIONS (id | time | type | amount | counterparty | country):
${rows}`;
}

export async function analyzeCase(c, customer, txns) {
  const prompt = `${caseContext(c, customer, txns)}

Return JSON with exactly these keys:
{"summary": "2-3 sentence plain-language summary of what looks suspicious",
 "typology": "closest AML/fraud typology (e.g. structuring, layering, mule account, high-risk jurisdiction, dormant account takeover)",
 "red_flags": ["3-5 short bullet strings each citing transaction IDs"],
 "legitimate_explanations": ["1-3 possible innocent explanations the analyst should check"],
 "recommended_action": "ESCALATE_STR" | "REQUEST_INFO" | "MONITOR" | "CLOSE",
 "rationale": "1-2 sentences",
 "sar_draft": "Draft suspicious transaction report narrative (who, what, when, how much, why suspicious) in 120-200 words. Start with 'DRAFT FOR ANALYST REVIEW.'"}`;
  try {
    const text = await call({ system: SYSTEM, prompt, json: true });
    const parsed = JSON.parse(text.replace(/^```json\s*|\s*```$/g, ''));
    return { ...parsed, source: 'gemini', model: MODEL, generatedAt: new Date().toISOString() };
  } catch (e) {
    return { ...offlineAnalysis(c, customer, txns), source: 'offline-template', note: 'Gemini unavailable: ' + String(e.message || e).slice(0, 160), generatedAt: new Date().toISOString() };
  }
}

export async function ask(c, customer, txns, question, history = []) {
  const prompt = `${caseContext(c, customer, txns)}

Previous conversation:\n${history.slice(-6).map(m => `${m.role}: ${m.text}`).join('\n') || '(none)'}

Analyst question: ${question}
Answer in under 120 words, grounded only in the case evidence above.`;
  try { return { answer: (await call({ system: SYSTEM, prompt })).trim(), source: 'gemini', model: MODEL }; }
  catch (e) {
    return { answer: `Gemini is not reachable right now (${String(e.message || e).slice(0, 100)}). Rules triggered on this case: ${c.hits.map(h => h.name).join('; ')}.`, source: 'offline-template' };
  }
}

function offlineAnalysis(c, customer) {
  const top = [...c.hits].sort((a, b) => b.points - a.points)[0];
  const act = c.score >= 70 ? 'ESCALATE_STR' : c.score >= 45 ? 'REQUEST_INFO' : 'MONITOR';
  return {
    summary: `${customer.name} triggered ${c.hits.length} monitoring rule(s); the strongest signal is "${top.name}". ${top.detail}`,
    typology: top.name,
    red_flags: c.hits.map(h => `${h.name}: ${h.detail}`),
    legitimate_explanations: ['Check whether activity matches documented business/occupation.', 'Request supporting documents for the source of funds.'],
    recommended_action: act,
    rationale: `Risk score ${c.score}/100 based on rule evidence.`,
    sar_draft: `DRAFT FOR ANALYST REVIEW. Customer ${customer.name} (${customer.id}) ${c.hits.map(h => h.detail).join(' ')} The pattern is consistent with ${top.name.toLowerCase()} and warrants review.`
  };
}
