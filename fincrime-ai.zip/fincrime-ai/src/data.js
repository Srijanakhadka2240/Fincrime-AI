// Synthetic, seeded data generator. All customers/transactions are fictional.
// Ground-truth typology labels (customer.injected) are used ONLY by the benchmark, never by the rules engine.
export const ANCHOR = Date.parse('2026-10-15T12:00:00Z');
const DAY = 864e5, HR = 36e5;

function rng(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const FIRST = ['Aarav','Sita','Ram','Gita','Bikash','Anita','Suresh','Mina','Prakash','Sunita','Dipesh','Rina','Kiran','Sabin','Puja','Nabin','Laxmi','Rohan','Asmita','Hari','Sangita','Bibek','Kamala','Rajan','Nisha','Manoj','Sarita','Deepak','Bina','Umesh'];
const LAST = ['Sharma','Thapa','Shrestha','Gurung','Rai','Karki','Adhikari','Tamang','Basnet','Khadka','Poudel','Maharjan','Bhandari','Joshi','Neupane','Magar'];
const BIZ = ['Himal Traders','Everest Agro','Lumbini Hardware','Annapurna Foods','Kathmandu Logistics','Pokhara Textiles','Mustang Spices','Terai Electronics','Janakpur Crafts','Bhaktapur Pottery','Chitwan Poultry','Sagarmatha Imports'];
const OK_COUNTRIES = ['NP','NP','NP','NP','IN','US','AE','GB'];
const HR_COUNTRIES = ['IR','KP','MM'];

export function generate(seed = 7, n = 60) {
  const r = rng(seed);
  const pick = a => a[Math.floor(r() * a.length)];
  const between = (a, b) => a + r() * (b - a);
  const round = (x, step = 100) => Math.round(x / step) * step;
  const customers = [], txns = [];
  let tid = 1;
  const add = (c, ts, type, amount, cp, country = 'NP', channel) => txns.push({
    id: 'T-' + String(tid++).padStart(5, '0'), customerId: c.id, ts: new Date(ts).toISOString(), type,
    amount: Math.round(amount), counterparty: cp, country,
    channel: channel || (type.startsWith('CASH') ? 'Branch' : type === 'WALLET_PAYMENT' ? 'Wallet' : 'Online')
  });

  // plan: first customers carry injected typologies, rest are normal / decoys
  const plan = [];
  const push = (t, k) => { for (let i = 0; i < k; i++) plan.push(t); };
  push('STRUCTURING', 5); push('PASSTHROUGH', 4); push('HIGHRISK', 4); push('VELOCITY', 4); push('DORMANT', 3);
  push('DECOY', 4);
  while (plan.length < n) plan.push(null);

  plan.forEach((typ, i) => {
    const biz = typ === 'DECOY' || (typ === null && r() < 0.18) || (typ === 'PASSTHROUGH' && r() < 0.5);
    const c = {
      id: 'C-' + String(1001 + i),
      name: biz ? BIZ[i % BIZ.length] + (i >= BIZ.length ? ' ' + (Math.floor(i / BIZ.length) + 1) : '') : pick(FIRST) + ' ' + pick(LAST),
      kind: biz ? 'Business' : 'Individual',
      occupation: biz ? 'Trading' : pick(['Teacher', 'Engineer', 'Shopkeeper', 'Student', 'Driver', 'Farmer', 'Nurse', 'Freelancer']),
      country: 'NP',
      riskRating: r() < 0.12 ? 'High' : r() < 0.4 ? 'Medium' : 'Low',
      expectedMonthly: biz ? round(between(2.5e6, 7e6), 10000) : round(between(6e4, 3.5e5), 1000),
      openedAt: new Date(ANCHOR - between(200, 2000) * DAY).toISOString().slice(0, 10),
      injected: typ && typ !== 'DECOY' ? typ : null
    };
    customers.push(c);
    const scale = c.expectedMonthly;
    // background behaviour over 60 days
    const nb = biz ? 18 + Math.floor(r() * 14) : 6 + Math.floor(r() * 10);
    if (typ !== 'DORMANT') for (let k = 0; k < nb; k++) {
      const ts = ANCHOR - r() * 60 * DAY;
      const roll = r();
      const amt = scale * between(0.02, biz ? 0.14 : 0.35);
      if (roll < 0.30) add(c, ts, 'TRANSFER_IN', amt, 'CP-' + Math.floor(r() * 40), pick(OK_COUNTRIES));
      else if (roll < 0.55) add(c, ts, 'TRANSFER_OUT', amt * 0.8, 'CP-' + Math.floor(r() * 40), pick(OK_COUNTRIES));
      else if (roll < 0.85) add(c, ts, 'WALLET_PAYMENT', amt * 0.3, 'M-' + Math.floor(r() * 25));
      else if (roll < 0.93) add(c, ts, 'CASH_DEPOSIT', Math.min(amt, 6e5), 'SELF');
      else add(c, ts, 'CASH_WITHDRAWAL', Math.min(amt, 4e5), 'SELF');
    }
    const evasive = r() < 0.2; // a fraction of injected cases are deliberately harder to catch
    const t0 = ANCHOR - between(3, 40) * DAY;
    if (typ === 'STRUCTURING') {
      const k = evasive ? 3 : 4 + Math.floor(r() * 3);
      for (let j = 0; j < k; j++) add(c, t0 + j * between(0.5, evasive ? 2.2 : 1.2) * DAY, 'CASH_DEPOSIT', between(0.84, 0.985) * 1e6, 'SELF');
    } else if (typ === 'PASSTHROUGH') {
      const rounds = evasive ? 1 : 2 + Math.floor(r() * 2);
      for (let j = 0; j < rounds; j++) {
        const base = t0 + j * 3 * DAY, amt = between(1.2e6, 4e6);
        add(c, base, 'TRANSFER_IN', amt, 'CP-' + Math.floor(100 + r() * 50), pick(OK_COUNTRIES));
        const parts = 2 + Math.floor(r() * 2), share = (evasive ? 0.93 : 0.96 + r() * 0.03) / parts;
        for (let p = 0; p < parts; p++) add(c, base + between(1, 20) * HR, 'TRANSFER_OUT', amt * share, 'CP-' + Math.floor(200 + r() * 50), pick(OK_COUNTRIES));
      }
    } else if (typ === 'HIGHRISK') {
      const k = evasive ? 1 : 2 + Math.floor(r() * 2);
      for (let j = 0; j < k; j++) add(c, t0 + j * 2 * DAY, r() < 0.5 ? 'TRANSFER_OUT' : 'TRANSFER_IN', between(evasive ? 4e4 : 1.5e5, evasive ? 1.2e5 : 9e5), 'CP-HR' + j, pick(HR_COUNTRIES));
    } else if (typ === 'VELOCITY') {
      const k = evasive ? 12 : 14 + Math.floor(r() * 8), start = t0 + between(0, 6) * HR;
      let tot = 0;
      for (let j = 0; j < k; j++) { const a = between(8e3, 4.5e4); tot += a; add(c, start + j * between(5, 22) * 60000, 'TRANSFER_IN', a, 'CP-M' + (300 + j), pick(OK_COUNTRIES), 'Wallet'); }
      add(c, start + 7 * HR, 'CASH_WITHDRAWAL', tot * 0.9, 'SELF');
    } else if (typ === 'DORMANT') {
      add(c, ANCHOR - between(260, 330) * DAY, 'WALLET_PAYMENT', scale * 0.05, 'M-1');
      const base = ANCHOR - between(2, 12) * DAY, k = evasive ? 1 : 2;
      for (let j = 0; j < k; j++) add(c, base + j * 0.5 * DAY, j === 0 ? 'TRANSFER_IN' : 'CASH_WITHDRAWAL', between(evasive ? 5.5e5 : 8e5, 2.2e6), j === 0 ? 'CP-' + Math.floor(400 + r() * 20) : 'SELF', 'NP');
    } else if (typ === 'DECOY') {
      // legitimate but large and lumpy: seasonal bulk receipts, paid out gradually (should NOT be flagged ideally)
      const amt = between(1.5e6, 3e6);
      add(c, t0, 'TRANSFER_IN', amt, 'CP-' + Math.floor(r() * 30), 'IN');
      add(c, t0 + 2 * DAY, 'TRANSFER_OUT', amt * 0.35, 'CP-' + Math.floor(r() * 30), 'IN');
      add(c, t0 + 5 * DAY, 'TRANSFER_OUT', amt * 0.3, 'CP-' + Math.floor(r() * 30), 'NP');
    }
  });
  txns.sort((a, b) => a.ts.localeCompare(b.ts));
  return { customers, txns };
}
