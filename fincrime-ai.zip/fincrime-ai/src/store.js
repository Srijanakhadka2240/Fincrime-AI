// Storage layer. Uses Cloud Firestore (REST API) when a Google project/credentials are available,
// otherwise falls back to in-memory storage so the app still runs locally. /api/health reports which is active.
import { getToken, getProject } from './google.js';

const toFs = v => {
  if (v === null || v === undefined) return { nullValue: null };
  if (typeof v === 'boolean') return { booleanValue: v };
  if (typeof v === 'number') return Number.isInteger(v) ? { integerValue: String(v) } : { doubleValue: v };
  if (typeof v === 'string') return { stringValue: v };
  if (Array.isArray(v)) return { arrayValue: { values: v.map(toFs) } };
  return { mapValue: { fields: Object.fromEntries(Object.entries(v).map(([k, x]) => [k, toFs(x)])) } };
};
const fromFs = v => {
  if ('nullValue' in v) return null;
  if ('booleanValue' in v) return v.booleanValue;
  if ('integerValue' in v) return Number(v.integerValue);
  if ('doubleValue' in v) return v.doubleValue;
  if ('stringValue' in v) return v.stringValue;
  if ('arrayValue' in v) return (v.arrayValue.values || []).map(fromFs);
  if ('mapValue' in v) return Object.fromEntries(Object.entries(v.mapValue.fields || {}).map(([k, x]) => [k, fromFs(x)]));
  return null;
};
const fieldsOf = o => Object.fromEntries(Object.entries(o).map(([k, v]) => [k, toFs(v)]));

export class Store {
  constructor() { this.mode = 'memory'; this.mem = {}; this.project = null; this.error = null; }

  async init() {
    try {
      this.project = await getProject();
      if (!this.project) throw new Error('no Google project detected');
      await getToken();
      this.base = `https://firestore.googleapis.com/v1/projects/${this.project}/databases/(default)/documents`;
      await this.#req('GET', '/customers?pageSize=1'); // proves Firestore is reachable and the DB exists
      this.mode = 'firestore';
    } catch (e) { this.mode = 'memory'; this.error = String(e.message || e); }
    return this.mode;
  }
  async #req(method, path, body) {
    const r = await fetch(this.base + path, {
      method, headers: { Authorization: 'Bearer ' + await getToken(), 'Content-Type': 'application/json' },
      body: body ? JSON.stringify(body) : undefined, signal: AbortSignal.timeout(20000)
    });
    if (!r.ok) throw new Error(`Firestore ${method} ${path.split('?')[0]} -> ${r.status} ${(await r.text()).slice(0, 200)}`);
    return r.json();
  }
  async list(col) {
    if (this.mode === 'memory') return Object.values(this.mem[col] || {});
    const out = []; let token = '';
    do {
      const j = await this.#req('GET', `/${col}?pageSize=300${token ? '&pageToken=' + encodeURIComponent(token) : ''}`);
      for (const d of j.documents || []) out.push(fromFs({ mapValue: { fields: d.fields || {} } }));
      token = j.nextPageToken || '';
    } while (token);
    return out;
  }
  async set(col, id, obj) {
    if (this.mode === 'memory') { (this.mem[col] ||= {})[id] = obj; return; }
    await this.#req('PATCH', `/${col}/${encodeURIComponent(id)}`, { fields: fieldsOf(obj) });
  }
  async setMany(col, items) { // items: [{id, ...}]
    if (this.mode === 'memory') { for (const o of items) (this.mem[col] ||= {})[o.id] = o; return; }
    const prefix = `projects/${this.project}/databases/(default)/documents/${col}/`;
    for (let i = 0; i < items.length; i += 200) {
      const writes = items.slice(i, i + 200).map(o => ({ update: { name: prefix + encodeURIComponent(o.id), fields: fieldsOf(o) } }));
      await this.#req('POST', ':batchWrite', { writes });
    }
  }
  async clear(col) {
    if (this.mode === 'memory') { this.mem[col] = {}; return; }
    for (const o of await this.list(col)) await this.#req('DELETE', `/${col}/${encodeURIComponent(o.id)}`);
  }
}
