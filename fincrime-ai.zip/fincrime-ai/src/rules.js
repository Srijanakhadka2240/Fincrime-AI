// Explainable AML rules engine. Every hit carries the evidence (transaction ids) that triggered it.
export const CONFIG = {
  ttrThreshold: 1_000_000,          // NPR cash threshold used for structuring detection (configurable)
  structuringBand: 0.8,             // deposits between 80% and 100% of threshold are "near-threshold"
  highRiskCountries: ['IR', 'KP', 'MM'], // configurable watchlist of high-risk jurisdictions
  alertAt: 25, mediumAt: 45, highAt: 70
};
const DAY = 864e5, HR = 36e5;
const t = x => Date.parse(x.ts);
const IN = new Set(['TRANSFER_IN', 'CASH_DEPOSIT']);
const OUT = new Set(['TRANSFER_OUT', 'CASH_WITHDRAWAL']);
const npr = n => 'NPR ' + Math.round(n).toLocaleString('en-US');

export function evaluate(customer, txnsIn, cfg = CONFIG) {
  const txns = [...txnsIn].sort((a, b) => t(a) - t(b));
  const hits = [];

  // R1 Structuring: >=3 near-threshold cash deposits inside 7 days
  const near = txns.filter(x => x.type === 'CASH_DEPOSIT' && x.amount >= cfg.structuringBand * cfg.ttrThreshold && x.amount < cfg.ttrThreshold);
  let best = [];
  for (let i = 0; i < near.length; i++) {
    const w = near.filter(y => t(y) >= t(near[i]) && t(y) - t(near[i]) <= 7 * DAY);
    if (w.length > best.length) best = w;
  }
  if (best.length >= 3) hits.push({
    id: 'STRUCTURING', name: 'Structuring below reporting threshold', points: 35 + (best.length >= 5 ? 5 : 0),
    detail: `${best.length} cash deposits of ${npr(Math.min(...best.map(x => x.amount)))}–${npr(Math.max(...best.map(x => x.amount)))} within 7 days, each just under the NPR ${cfg.ttrThreshold.toLocaleString('en-US')} threshold (total ${npr(best.reduce((s, x) => s + x.amount, 0))}).`,
    txnIds: best.map(x => x.id)
  });

  // R2 Rapid pass-through: large inflow, >=90% leaves within 24h
  const occ = [];
  for (const x of txns) {
    if (x.type !== 'TRANSFER_IN' || x.amount < 500_000) continue;
    const outs = txns.filter(y => OUT.has(y.type) && t(y) > t(x) && t(y) - t(x) <= DAY);
    const sum = outs.reduce((s, y) => s + y.amount, 0);
    if (sum >= 0.9 * x.amount) occ.push({ x, outs, sum });
  }
  if (occ.length) hits.push({
    id: 'PASSTHROUGH', name: 'Rapid movement of funds (pass-through)', points: occ.length >= 2 ? 30 : 15,
    detail: `${occ.length} instance(s) where ≥90% of a large inflow left the account within 24h (e.g. ${npr(occ[0].x.amount)} in, ${npr(occ[0].sum)} out).`,
    txnIds: occ.flatMap(o => [o.x.id, ...o.outs.map(y => y.id)])
  });

  // R3 High-risk jurisdiction
  const hr = txns.filter(x => cfg.highRiskCountries.includes(x.country));
  if (hr.length) {
    const tot = hr.reduce((s, x) => s + x.amount, 0);
    hits.push({
      id: 'HIGHRISK', name: 'High-risk jurisdiction exposure', points: 25 + (tot >= 500_000 ? 10 : 0),
      detail: `${hr.length} transaction(s) with counterparties in ${[...new Set(hr.map(x => x.country))].join(', ')} totalling ${npr(tot)}.`,
      txnIds: hr.map(x => x.id)
    });
  }

  // R4 Velocity / mule pattern: >=12 inbound transfers from >=8 counterparties in 6h
  const inb = txns.filter(x => x.type === 'TRANSFER_IN');
  let vbest = [];
  for (let i = 0; i < inb.length; i++) {
    const w = inb.filter(y => t(y) >= t(inb[i]) && t(y) - t(inb[i]) <= 6 * HR);
    if (w.length > vbest.length && new Set(w.map(y => y.counterparty)).size >= 8) vbest = w;
  }
  if (vbest.length >= 12) {
    const last = t(vbest[vbest.length - 1]);
    const cash = txns.filter(y => y.type === 'CASH_WITHDRAWAL' && t(y) >= last && t(y) - last <= 12 * HR);
    hits.push({
      id: 'VELOCITY', name: 'Mule-like velocity (many senders, fast cash-out)', points: 30 + (cash.length ? 5 : 0),
      detail: `${vbest.length} inbound transfers from ${new Set(vbest.map(y => y.counterparty)).size} different senders within 6 hours (${npr(vbest.reduce((s, x) => s + x.amount, 0))})${cash.length ? ', followed by a cash withdrawal' : ''}.`,
      txnIds: [...vbest, ...cash].map(x => x.id)
    });
  }

  // R5 Dormant account reactivation: >=180 day gap then >=NPR 500k within 7 days
  for (let i = 1; i < txns.length; i++) {
    if (t(txns[i]) - t(txns[i - 1]) >= 180 * DAY) {
      const w = txns.filter(y => t(y) >= t(txns[i]) && t(y) - t(txns[i]) <= 7 * DAY);
      const tot = w.reduce((s, y) => s + y.amount, 0);
      if (tot >= 500_000) { hits.push({
        id: 'DORMANT', name: 'Dormant account suddenly active', points: 25,
        detail: `No activity for ${Math.round((t(txns[i]) - t(txns[i - 1])) / DAY)} days, then ${npr(tot)} moved within 7 days.`,
        txnIds: w.map(x => x.id)
      }); break; }
    }
  }

  // R6 Volume spike vs expected profile: 7-day inbound > 2.5x expected monthly
  let sp = null;
  const credits = txns.filter(x => IN.has(x.type));
  for (const x of credits) {
    const w = credits.filter(y => t(y) <= t(x) && t(x) - t(y) <= 7 * DAY);
    const tot = w.reduce((s, y) => s + y.amount, 0);
    if (tot > 2.5 * customer.expectedMonthly && (!sp || tot > sp.tot)) sp = { tot, w };
  }
  if (sp) hits.push({
    id: 'SPIKE', name: 'Activity inconsistent with customer profile', points: 20,
    detail: `${npr(sp.tot)} received in 7 days vs expected monthly turnover of ${npr(customer.expectedMonthly)}.`,
    txnIds: sp.w.map(x => x.id)
  });

  let score = hits.reduce((s, h) => s + h.points, 0);
  if (hits.length >= 2) score += 10;                              // corroboration: independent signals reinforce each other
  if (score > 0 && customer.riskRating === 'High') score += 5;
  score = Math.min(100, score);
  const severity = score >= cfg.highAt ? 'High' : score >= cfg.mediumAt ? 'Medium' : score >= cfg.alertAt ? 'Low' : 'None';
  return { score, severity, hits, alert: score >= cfg.alertAt };
}
