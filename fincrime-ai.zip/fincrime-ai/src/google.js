// Minimal Google auth helper (no SDK needed): on Cloud Run the attached service account token comes from the metadata server.
// Locally, set GOOGLE_ACCESS_TOKEN (e.g. $(gcloud auth print-access-token)).
const META = 'http://metadata.google.internal/computeMetadata/v1/';
let cached = { token: null, exp: 0 };
let projectCache = null;

async function meta(path) {
  const r = await fetch(META + path, { headers: { 'Metadata-Flavor': 'Google' }, signal: AbortSignal.timeout(2500) });
  if (!r.ok) throw new Error('metadata ' + r.status);
  return r;
}
export async function getToken() {
  if (process.env.GOOGLE_ACCESS_TOKEN) return process.env.GOOGLE_ACCESS_TOKEN;
  if (cached.token && Date.now() < cached.exp - 60000) return cached.token;
  const j = await (await meta('instance/service-accounts/default/token')).json();
  cached = { token: j.access_token, exp: Date.now() + j.expires_in * 1000 };
  return cached.token;
}
export async function getProject() {
  if (projectCache) return projectCache;
  projectCache = process.env.GOOGLE_CLOUD_PROJECT || process.env.GCLOUD_PROJECT || process.env.FIREBASE_PROJECT_ID;
  if (!projectCache) { try { projectCache = (await (await meta('project/project-id')).text()).trim(); } catch { projectCache = null; } }
  return projectCache;
}
