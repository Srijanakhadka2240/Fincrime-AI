# FinCrime AI – AI-assisted AML & fraud case tracking

Built for the Google Cloud **AI Builder Cup**. Team: **FinCrime AI**.

Compliance teams drown in rule-based alerts and spend most of their time writing up cases. FinCrime AI keeps the
**explainable rules engine** regulators trust, and adds **Gemini** to turn each alert into an investigation brief and a draft
suspicious-transaction report, with the analyst always making the final decision.

## What it does
- **Detects** six AML/fraud typologies: structuring below the reporting threshold, rapid pass-through, high-risk jurisdictions,
  mule-like velocity, dormant-account reactivation, and profile mismatch. Each hit lists the exact transactions that triggered it.
- **Screens transactions in real time** (`POST /api/screen`): re-scores the customer, writes to Firestore, opens/updates a case.
- **Explains with Gemini**: summary, typology, red flags citing transaction IDs, innocent explanations to check, recommended action,
  and a draft STR/SAR narrative. A case copilot answers analyst questions grounded in the case evidence.
- **Tracks cases** (Open → Escalated / Monitoring / Closed) with a full audit timeline stored in Firestore.

## Google technologies
| Tech | How it is used |
|---|---|
| **Cloud Run** | Hosts the Node.js API + dashboard (container built from `Dockerfile`, runs as a least-privilege service account) |
| **Firestore** | System of record: `customers`, `transactions`, `cases` (incl. AI analysis + timeline). Rules deny all direct client access |
| **Firebase** | Firebase Hosting fronts Cloud Run (`firebase.json` rewrite) and deploys the Firestore security rules |
| **Gemini** (`gemini-2.5-flash`) | Case analysis (structured JSON), draft STR narrative, case copilot. Via Vertex AI with the Cloud Run service account, or a Gemini API key |

The app has **zero npm dependencies** (Node 20+ built-ins and the Google REST APIs), so builds are fast and the supply chain is tiny.
If Firestore or Gemini is unreachable (e.g. local dev) it degrades gracefully: in-memory store / offline template, and the UI labels which is active.

## Run locally
```bash
node server.js                       # http://localhost:8080, in-memory store
GEMINI_API_KEY=... node server.js    # real Gemini (key from https://aistudio.google.com/apikey)
npm run check:gemini                 # verifies Gemini access
npm run benchmark                    # detection benchmark on synthetic data
```
To use real Firestore locally: `GOOGLE_CLOUD_PROJECT=<id> GOOGLE_ACCESS_TOKEN=$(gcloud auth print-access-token) node server.js`

## Deploy
```bash
PROJECT_ID=<your-gcp-project> ./deploy.sh
curl https://<your-project>.web.app/api/health    # expect "store":"firestore"
```

## Data and limitations
All customers and transactions are **synthetic** (seeded generator in `src/data.js`). Thresholds and the high-risk country list
are configurable in `src/rules.js` and must be set per institution's policy and local regulation. Detection metrics from
`npm run benchmark` are measured on synthetic data with injected typologies and are **not** a claim of real-world accuracy.
AI output is a draft; it never files anything automatically.

## Structure
`server.js` API + static hosting · `src/rules.js` rules engine · `src/gemini.js` Gemini client · `src/store.js` Firestore/memory store ·
`src/data.js` synthetic data · `public/index.html` dashboard · `Dockerfile`, `firebase.json`, `firestore.rules`, `deploy.sh`
