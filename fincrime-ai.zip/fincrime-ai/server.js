import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';
import { generate, ANCHOR } from './src/data.js';
import { evaluate, CONFIG } from './src/rules.js';
import { Store } from './src/store.js';
import { analyzeCase, ask, geminiInfo } from './src/gemini.js';

const PORT = process.env.PORT || 8080;
const ROOT = fileURLToPath(new URL('./public/', import.meta.url));
const store = new Store();
const S = { customers: new Map(), txns: [], cases: new Map(), live: 0 };

const txnsOf = id => S.txns.filter(t => t.customerId === id);
const now = () => new Date().toISOString();

async function rescore(customerId, actor = 'engine') {
  const c = S.customers.get(customerId), res = evaluate(c, txnsOf(customerId));
  const existing = [...S.cases.values()].find(x => x.customerId === customerId);
  if (!res.alert && !existing) return { res, case: null };
  let cs = existing;
  if (!cs) {
    cs = { id: 'CASE-' + String(S.cases.size + 1).padStart(3, '0'), customerId, status: 'Open', analysis: null, notes: [], timeline: [{ ts: now(), actor, action: 'Case opened', note: '' }], createdAt: now() };
  }
  const changed = !existing || cs.score !== res.score;
  Object.assign(cs, { score: res.score, severity: res.severity === 'None' ? 'Low' : res.severity, hits: res.hits, updatedAt: now() });
  if (existing && changed) cs.timeline.push({ ts: now(), actor, action: `Re-scored to ${res.score}`, note: '' });
  S.cases.set(cs.id, cs);
  await store.set('cases', cs.id, cs);
  return { res, case: cs };
}

async function boot() {
  const mode = await store.init();
  let customers = await store.list('customers');
  if (!customers.length) {
    const d = generate(7, 60);
    await store.setMany('customers', d.customers);
    await store.setMany('transactions', d.txns);
    customers = d.customers;
    S.txns = d.txns;
  } else S.txns = await store.list('transactions');
  customers.forEach(c => S.customers.set(c.id, c));
  (await store.list('cases')).forEach(c => S.cases.set(c.id, c));
  S.live = S.txns.filter(t => t.id.startsWith('T-L')).length;
  if (!S.cases.size) for (const c of customers) await rescore(c.id);
  console.log(`FinCrime AI ready | store=${mode}${store.error ? ' (' + store.error + ')' : ''} | customers=${S.customers.size} txns=${S.txns.length} cases=${S.cases.size}`);
}

const send = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(obj)); };
const body = req => new Promise(r => { let d = ''; req.on('data', c => d += c); req.on('end', () => { try { r(JSON.parse(d || '{}')); } catch { r({}); } }); });
const caseView = c => ({ ...c, customer: S.customers.get(c.customerId) });
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.svg': 'image/svg+xml', '.png': 'image/png' };

const routes = {
  'GET /api/health': async () => ({ status: 'ok', store: store.mode, storeError: store.error, project: store.project, gemini: geminiInfo(), geminiConfigured: !!process.env.GEMINI_API_KEY || store.mode === 'firestore', customers: S.customers.size, transactions: S.txns.length, cases: S.cases.size }),
  'GET /api/summary': async () => {
    const cs = [...S.cases.values()];
    return {
      customers: S.customers.size, transactions: S.txns.length, alerts: cs.length,
      high: cs.filter(c => c.severity === 'High').length, open: cs.filter(c => c.status === 'Open').length,
      escalated: cs.filter(c => c.status === 'Escalated').length, closed: cs.filter(c => c.status === 'Closed').length,
      config: CONFIG
    };
  },
  'GET /api/cases': async () => [...S.cases.values()].sort((a, b) => b.score - a.score).map(c => ({ ...caseView(c), txnCount: txnsOf(c.customerId).length })),
  'GET /api/customers': async () => [...S.customers.values()].map(({ id, name, kind }) => ({ id, name, kind })),
  'POST /api/reset': async () => {
    await store.clear('cases'); await store.clear('transactions'); await store.clear('customers');
    S.customers.clear(); S.cases.clear(); S.txns = []; await boot(); return { ok: true };
  }
};

async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const key = `${req.method} ${url.pathname}`;
  try {
    if (routes[key]) return send(res, 200, await routes[key](req));
    let m;
    if ((m = url.pathname.match(/^\/api\/cases\/([\w-]+)$/)) && req.method === 'GET') {
      const c = S.cases.get(m[1]); if (!c) return send(res, 404, { error: 'not found' });
      return send(res, 200, { ...caseView(c), txns: txnsOf(c.customerId) });
    }
    if ((m = url.pathname.match(/^\/api\/cases\/([\w-]+)\/analyze$/)) && req.method === 'POST') {
      const c = S.cases.get(m[1]); if (!c) return send(res, 404, { error: 'not found' });
      c.analysis = await analyzeCase(c, S.customers.get(c.customerId), txnsOf(c.customerId));
      c.timeline.push({ ts: now(), actor: c.analysis.source === 'gemini' ? 'Gemini' : 'Offline template', action: 'AI analysis generated', note: c.analysis.recommended_action });
      await store.set('cases', c.id, c);
      return send(res, 200, c.analysis);
    }
    if ((m = url.pathname.match(/^\/api\/cases\/([\w-]+)\/status$/)) && req.method === 'POST') {
      const c = S.cases.get(m[1]); if (!c) return send(res, 404, { error: 'not found' });
      const b = await body(req);
      if (!['Open', 'Escalated', 'Monitoring', 'Closed'].includes(b.status)) return send(res, 400, { error: 'bad status' });
      c.status = b.status; c.timeline.push({ ts: now(), actor: 'Analyst', action: `Status → ${b.status}`, note: String(b.note || '').slice(0, 500) });
      c.updatedAt = now(); await store.set('cases', c.id, c);
      return send(res, 200, caseView(c));
    }
    if ((m = url.pathname.match(/^\/api\/cases\/([\w-]+)\/ask$/)) && req.method === 'POST') {
      const c = S.cases.get(m[1]); if (!c) return send(res, 404, { error: 'not found' });
      const b = await body(req);
      return send(res, 200, await ask(c, S.customers.get(c.customerId), txnsOf(c.customerId), String(b.question || '').slice(0, 500), b.history || []));
    }
    if (key === 'POST /api/screen') { // real-time transaction screening
      const b = await body(req), cust = S.customers.get(b.customerId);
      const amount = Number(b.amount);
      if (!cust || !(amount > 0)) return send(res, 400, { error: 'customerId and positive amount required' });
      const t0 = performance.now();
      const before = evaluate(cust, txnsOf(cust.id));
      const t = { id: 'T-L' + String(++S.live).padStart(4, '0'), customerId: cust.id, ts: now(), type: b.type || 'TRANSFER_OUT', amount: Math.round(amount), counterparty: b.counterparty || 'CP-LIVE', country: (b.country || 'NP').toUpperCase(), channel: 'Live' };
      S.txns.push(t); await store.set('transactions', t.id, t);
      const { res: after, case: cs } = await rescore(cust.id, 'Live screening');
      return send(res, 200, { transaction: t, before: { score: before.score, severity: before.severity }, after: { score: after.score, severity: after.severity, alert: after.alert }, newRules: after.hits.map(h => h.name).filter(n => !before.hits.some(x => x.name === n)), caseId: cs?.id || null, decision: after.score >= 70 ? 'HOLD & ESCALATE' : after.alert ? 'ALERT - REVIEW' : 'PASS', latencyMs: +(performance.now() - t0).toFixed(1) });
    }
    // static files
    let p = normalize(url.pathname === '/' ? '/index.html' : url.pathname).replace(/^(\.\.[/\\])+/, '');
    const data = await readFile(join(ROOT, p));
    res.writeHead(200, { 'Content-Type': MIME[extname(p)] || 'application/octet-stream' }); res.end(data);
  } catch (e) {
    if (e.code === 'ENOENT') return send(res, 404, { error: 'not found' });
    console.error(e); send(res, 500, { error: String(e.message || e) });
  }
}

await boot();
http.createServer(handle).listen(PORT, () => console.log('listening on ' + PORT));
