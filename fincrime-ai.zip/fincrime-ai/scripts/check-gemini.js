// Run on your machine / Cloud Shell to verify Gemini access: GEMINI_API_KEY=... npm run check:gemini
import { analyzeCase } from '../src/gemini.js';
import { generate } from '../src/data.js';
import { evaluate } from '../src/rules.js';
const { customers, txns } = generate(7, 60);
const cust = customers[0], mine = txns.filter(t => t.customerId === cust.id), r = evaluate(cust, mine);
const out = await analyzeCase({ id: 'CASE-TEST', ...r, hits: r.hits }, cust, mine);
console.log(out.source === 'gemini' ? 'GEMINI OK ->' : 'FELL BACK TO OFFLINE ->', JSON.stringify(out, null, 2).slice(0, 900));
process.exit(out.source === 'gemini' ? 0 : 1);
