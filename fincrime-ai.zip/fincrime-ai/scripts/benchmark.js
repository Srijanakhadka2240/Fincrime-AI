// Detection benchmark on SYNTHETIC data with injected ground truth (labels never seen by the rules).
import { generate } from '../src/data.js';
import { evaluate } from '../src/rules.js';
const seeds = Array.from({ length: 20 }, (_, i) => i + 1);
const typMap = { STRUCTURING: 'STRUCTURING', PASSTHROUGH: 'PASSTHROUGH', HIGHRISK: 'HIGHRISK', VELOCITY: 'VELOCITY', DORMANT: 'DORMANT' };
let tp = 0, fp = 0, fn = 0, tn = 0, scoreMs = [], per = {}, flaggedFraud = 0, flaggedAll = 0, highTp = 0, highAll = 0;
for (const seed of seeds) {
  const { customers, txns } = generate(seed, 60);
  const by = new Map(); txns.forEach(t => (by.get(t.customerId) || by.set(t.customerId, []).get(t.customerId)).push(t));
  for (const c of customers) {
    const t0 = performance.now(); const r = evaluate(c, by.get(c.id) || []); scoreMs.push(performance.now() - t0);
    const bad = !!c.injected;
    if (bad) { per[c.injected] ||= { n: 0, hit: 0, typ: 0 }; per[c.injected].n++; if (r.alert) per[c.injected].hit++; if (r.hits.some(h => h.id === typMap[c.injected])) per[c.injected].typ++; }
    if (r.alert && bad) tp++; else if (r.alert && !bad) fp++; else if (!r.alert && bad) fn++; else tn++;
    if (r.severity === 'High') { highAll++; if (bad) highTp++; }
  }
}
const p = tp / (tp + fp), rc = tp / (tp + fn);
scoreMs.sort((a, b) => a - b);
const out = {
  runs: seeds.length, customersPerRun: 60, totalCustomers: seeds.length * 60, injectedSuspicious: tp + fn,
  precision: +p.toFixed(3), recall: +rc.toFixed(3), f1: +(2 * p * rc / (p + rc)).toFixed(3),
  falsePositives: fp, falseNegatives: fn, falsePositiveRate: +(fp / (fp + tn)).toFixed(4),
  highSeverityPrecision: +(highTp / highAll).toFixed(3),
  perTypology: Object.fromEntries(Object.entries(per).map(([k, v]) => [k, { cases: v.n, alerted: v.hit, recall: +(v.hit / v.n).toFixed(2), correctRuleFired: +(v.typ / v.n).toFixed(2) }])),
  scoringLatencyMs: { median: +scoreMs[Math.floor(scoreMs.length / 2)].toFixed(3), p95: +scoreMs[Math.floor(scoreMs.length * 0.95)].toFixed(3) }
};
console.log(JSON.stringify(out, null, 2));
